from dis import disco
import socket
import random
import threading
import time

client_port = random.randint(10000, 60000)
udp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_id = random.randint(1,50000) 
bytes_to_send= str.encode(str(client_id))
sleep_time = 5
server_ip = "127.0.0.1"
server_port = 55555
x=0
def sendto():
    print("please choose a client to connect to :  ")
    peer_client_id = input()
    udp_client_socket.sendto(str.encode(peer_client_id), (server_ip, server_port))
    peer_client_info = udp_client_socket.recvfrom(1024)
    peer_client_port = (peer_client_info[0].decode())
    while True:
        msg = input("please Enter the message you want to send to the client : \n")
        udp_client_socket.sendto(str.encode(msg), (server_ip, int(peer_client_port)))
while True:

    udp_client_socket.sendto(bytes_to_send,(server_ip, server_port))
    client_list = udp_client_socket.recvfrom(1024)
    time.sleep(sleep_time)
    print("Online Clients Id Addresses " +client_list[0].decode())
    break
sendto()
def listen():
    while True:
        data = udp_client_socket.recv(1024)
        print('\rpeer: {}\n> '.format(data.decode()), end='')

listener = threading.Thread(target=listen, daemon=True);
listener.start()


# send messages
# equiv: echo 'xxx' | nc -u -p 50002 x.x.x.x 50001

