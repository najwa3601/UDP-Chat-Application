from dis import disco
import socket
import random
import threading
import time

client_port = random.randint(10000, 60000)
udp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sleep_time = 5
server_ip = "127.0.0.1"
server_port = 55555
udp_client_socket.bind((server_ip, client_port))
udp_client_socket.sendto(b'0',(server_ip, server_port))
while True:
    data  = udp_client_socket.recv(1024).decode()
    if data.strip() == 'ready':
        print("checked with server")
        break
client_list = udp_client_socket.recvfrom(1024)
time.sleep(sleep_time)
print("Online Clients Id Addresses are" +client_list[0].decode()+ " \n")

def choose_client():
    print("please choose a client to connect to :  ")
    peer_client_id = input()
    udp_client_socket.sendto(str.encode(peer_client_id), (server_ip, server_port))
    peer_client_info = udp_client_socket.recvfrom(1024)
    peer_client_port = (peer_client_info[0]).decode()
    return peer_client_port
peer_client_info=(choose_client())
manual = peer_client_info.split(",")
strx= ""

def listen():
    while True:
        data = udp_client_socket.recv(1024)
        print('\rpeer: {}\n> '.format(data.decode()), end='')

listener = threading.Thread(target=listen, daemon=True);
listener.start()
print(strx)
while True:
    msg = input('> ')

    udp_client_socket.sendto(str.encode(msg), (server_ip,int(manual[1][1:-2])))



