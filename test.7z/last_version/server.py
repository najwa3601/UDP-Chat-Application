import socket
import time
import math , random

local_ip = "127.0.0.1"
local_port = 55555

udp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
udp_server_socket.bind((local_ip, local_port))
print("Udp server is up")

client_list = {}
connected_clients = []

x= 0
sleep_time = 5

def broacast():
    client_ids = ""
    for client in client_list:
        client_ids += str(client) + ","
    print(client_list)
    for client in client_list:
        udp_server_socket.sendto(str.encode(client_ids), (client_list[client]["address"]))


    
    
while True :
    print("test")
    data, address = udp_server_socket.recvfrom(128)
    print('connection from: {}'.format(address))
    client_list[random.randint(10000, 60000)] = {"address": address, "status": False}
    udp_server_socket.sendto(b'ready', address)
    print("broadcast")
    if len(client_list) > 2:
        broacast()
        break
    print("test2")
    time.sleep(2)

print("test")
print(client_list)

c2_id,c12_adress = udp_server_socket.recvfrom(1024)
x += 1
c1_id , c21_address = udp_server_socket.recvfrom(1024)
x += 1
c12_address = client_list[int(c2_id)]["address"]
c21_address = client_list[int(c1_id)]["address"]

if x == 2:
    udp_server_socket.sendto('{} '.format(c12_address).encode(), c21_address)
    udp_server_socket.sendto('{} '.format(c21_address).encode(), c12_address)
    
time.sleep(10)